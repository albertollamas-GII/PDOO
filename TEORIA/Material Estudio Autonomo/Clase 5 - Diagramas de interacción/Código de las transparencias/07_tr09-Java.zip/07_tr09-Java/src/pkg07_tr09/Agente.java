package pkg07_tr09;

import java.util.Date;

/*
 * Corresponde a la implementación de la transparencia 9 de la unidad 07
 */

public class Agente {
    
    private SistemaMeteorologico meteo; //Esta información nos la daría un diagrama de clases
    private String ciudadHabitual = "Granada"; //Esta información nos la daría un diagrama de clases
    
    /**
     * ¿Cómo sabemos que este método tiene visibilidad de paquete y devuelve un String?
     * ¿Cómo sabemos que el parámetro dia es de tipo Date?
     * Por el diagrama de secuencia únicamente no lo podemos saber. Esta información
     * nos la proporciona un diagrama de clases. Para este ejemplo no tenemos diagrama
     * de clases, pero sí en los supuestos prácticos que tienes para el estudio autónomo
     */
    String dimeTiempo(Date dia){
    
        String tiempo; // No se nos debe olvidar declarar las variables locales
        
        String ciudad = this.posicionActual(); //1.1 (se podría omitir "this.")
            //Que ciudad es de tipo String también nos lo diría el diagrama de clases
            
        if(ciudad!=null){ // zona de encima de la línea punteada en el fragmento alt
            tiempo = meteo.dimeTiempo(ciudad, dia); //1.2
        } else { //zona debajo de la línea punteada en el fragmento alt
            tiempo = meteo.dimeTiempo(ciudadHabitual,dia); //1.3
        }
        
        return tiempo; //No debemos olvidar el return porque el paso 1 devuelve el valor de tiempo
    
    }

    private String posicionActual() {
        throw new UnsupportedOperationException("Método todavía sin implementar"); 
    }
            
}
