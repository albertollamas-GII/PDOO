
package pkg07_tr13;

/*
   * Corresponde a la implementación de la transparencia 13 de la unidad 07
*/ 

class Reserva {
    
    private int hora, comensales, id;
    
    Reserva(int hora, int comensales, int id){
        this.hora = hora;
        this.comensales = comensales;
        this.id = id;
    }
}
