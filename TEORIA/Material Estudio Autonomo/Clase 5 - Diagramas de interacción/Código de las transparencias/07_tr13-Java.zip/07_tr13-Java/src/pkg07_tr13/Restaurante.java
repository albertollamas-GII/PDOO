package pkg07_tr13;

import java.util.ArrayList;

/*
   * Corresponde a la implementación de la transparencia 13 de la unidad 07
*/ 
public class Restaurante {
    
    private ArrayList<Reserva> reservas = new ArrayList();
    
    void reservar(int hora, int comensales, int id){
    
        Boolean disponible = this.comprobarDisponibilidad(hora, comensales); //1.1
        if(disponible){
            Reserva re = new Reserva(hora, comensales, id); //1.2 - crear es una llamada al constructor
            reservas.add(re); //1.3 - incluir en un ArrayList se hace con add
        }
    }

    private Boolean comprobarDisponibilidad(int hora, int comensales) {
        throw new UnsupportedOperationException("Método todavía sin implementar");
    }
    
}
