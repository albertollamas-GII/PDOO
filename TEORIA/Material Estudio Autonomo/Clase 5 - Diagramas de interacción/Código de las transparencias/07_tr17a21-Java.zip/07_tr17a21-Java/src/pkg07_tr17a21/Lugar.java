package pkg07_tr17a21;

/*
   * Corresponde a la implementación de las transparencias 17, 18, 19, 20 y 21 de la unidad 07
*/ 

class Lugar {

    private int latitud;
    private int longitud;
    
    public float distancia(Lugar punto){
        throw new UnsupportedOperationException("Método todavía sin implementar");
    }
    
}
