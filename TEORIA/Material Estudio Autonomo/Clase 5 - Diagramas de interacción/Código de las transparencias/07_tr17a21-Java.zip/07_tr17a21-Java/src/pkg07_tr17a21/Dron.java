
package pkg07_tr17a21;

/*
   * Corresponde a la implementación de las transparencias 17, 18, 19, 20 y 21 de la unidad 07
*/ 

class Dron {

    private int id;
    private float altura;
    private Lugar posicion;
    private Controlador controlador;
    
    public int getId(){
        return id;
    }
    
    public float getAltura(){
        return altura;
    }
    
    public Lugar getPosicion(){
        return posicion;
    }
    
    public void navegar(Lugar destino){
        throw new UnsupportedOperationException("Método todavía sin implementar");
    }
    
    public void aterrizar(){
        throw new UnsupportedOperationException("Método todavía sin implementar");
    }
    
}
