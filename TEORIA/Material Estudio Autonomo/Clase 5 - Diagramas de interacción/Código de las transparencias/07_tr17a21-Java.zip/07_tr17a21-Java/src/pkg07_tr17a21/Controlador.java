package pkg07_tr17a21;

import java.util.ArrayList;

/*
   * Corresponde a la implementación de las transparencias 17, 18, 19, 20 y 21 de la unidad 07
*/ 
public class Controlador {
    
    ArrayList<Dron> aparatos = new ArrayList();
    
    //Transparencia 18:
    public void llevarDronA(Lugar punto){
        Dron dron = this.dronMasCercano(punto); //1
        dron.navegar(punto); //2
    }
    
    //Transparencia 19:
    public float alturaDron(int idDron){
        Dron dron = aparatos.get(idDron); //1
        float altura = dron.getAltura(); //2
        return altura;
    }
    
    //Transparencia 20:
    public void incluirNuevoDron(Dron dron, Lugar lugar){
        dron.navegar(lugar); //1.1
        aparatos.add(dron); //1.2
    }
    
    //Transparencia 21:
    public void aterrizarDronesBajoAltura(float alt){
        Dron dron;
        float altura;
        for(int i=0; i<aparatos.size(); i++){ //*[paratodos]
            dron = aparatos.get(i); //1
            altura = dron.getAltura(); //2
            if(altura<=alt) //[altura<=alt]
                dron.aterrizar(); //3
        }
        
        /**
         * Todavía mejor:
         * float altura;
         * for(Dron dron: aparatos) {
            altura = dron.getAltura();
            if(altura<=alt)
                dron.aterrizar();
            }
         * 
         */
    }
    
    private Dron dronMasCercano(Lugar punto){
        throw new UnsupportedOperationException("Método todavía sin implementar");
    }
    
    private Dron getDron(int idDron){
        throw new UnsupportedOperationException("Método todavía sin implementar");
    }
    
}
