package pkg07_tr07;

import java.util.Date;

/*
 * Corresponde a la implementación de la transparencia 7 de la unidad 07
 */

public class Agente {
    
    private SistemaMeteorologico meteo; //Esta información nos la daría un diagrama de clases
    
    /**
     * ¿Cómo sabemos que este método tiene visibilidad de paquete y devuelve un String?
     * ¿Cómo sabemos que el parámetro dia es de tipo Date?
     * Por el diagrama de secuencia únicamente no lo podemos saber. Esta información
     * nos la proporciona un diagrama de clases. Para este ejemplo no tenemos diagrama
     * de clases, pero sí en los supuestos prácticos que tienes para el estudio autónomo
     */
    String dimeTiempo(Date dia){
    
        String ciudad = this.posicionActual(); //1.1 (se podría omitir "this.")
            //Que ciudad es de tipo String también nos lo diría el diagrama de clases
        String tiempo = meteo.dimeTiempo(ciudad, dia); //1.2 
 
        return tiempo; //1.3
    
    }

    private String posicionActual() {
        throw new UnsupportedOperationException("Método todavía sin implementar"); 
    }
            
}
