package pkg07_tr07;

import java.util.Date;

/*
 * Corresponde a la implementación de la transparencia 7 de la unidad 07
 */

class SistemaMeteorologico {

    String dimeTiempo(String ciudad, Date dia) {
        throw new UnsupportedOperationException("Método todavía sin implementar"); 
    }
    
}
