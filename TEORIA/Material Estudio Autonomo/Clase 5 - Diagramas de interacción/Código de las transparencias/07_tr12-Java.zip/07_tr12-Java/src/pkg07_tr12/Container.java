/*
   * Corresponde a la implementación de la transparencia 12 de la unidad 07
*/  
package pkg07_tr12;

class Container {
    
}
