package pkg07_tr12;

import java.util.ArrayList;

  
/*
   * Corresponde a la implementación de la transparencia 12 de la unidad 07
*/  
public class Carguero {

    ArrayList<Container> contenedores = new ArrayList<>(); //Los atributos los sabemos por el diagrama de clases
    int huecos = 0;
    
    void llenar(){
    
        int huecos = this.getHuecos(); //1.1
        int containersEnMuelle = contenedores.size(); //1.2
        
        Container cont;
        int i = 0;
        while(huecos!=0 && containersEnMuelle>0) { //En este caso el loop se interpreta como un while
            cont = contenedores.get(i); //1.3
            this.cargar(cont); //1.4
            huecos--;
            containersEnMuelle++;
        }
    }

    int getHuecos() {
        return huecos;
    }

    void cargar(Container cont) {
        throw new UnsupportedOperationException("Método todavía no implementado");
    }
}
