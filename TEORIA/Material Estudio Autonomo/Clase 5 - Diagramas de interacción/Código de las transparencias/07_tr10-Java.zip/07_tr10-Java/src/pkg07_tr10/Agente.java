
package pkg07_tr10;

import java.util.ArrayList;
import java.util.Date;

public class Agente {
    
    private SistemaMeteorologico meteo; //Esta información nos la daría un diagrama de clases
    private String ciudadHabitual = "Granada"; //Esta información nos la daría un diagrama de clases


    /*
    * Corresponde a la implementación de la transparencia 10 de la unidad 07
    */    
    String dimeTiempo(Date dia){
    
        String tiempo=""; // No se nos debe olvidar declarar las variables locales
        
        Date diaActual = this.diaActual(); //1.1 (se podría omitir "this.") 
            // En el diagrama hay una errata: debería poner diaActual en lugar de hoy
        
        if(dia.getTime()-diaActual.getTime()<15){ //El fragmento opt se suele usar para condicionales sin else
        
            String ciudad = this.posicionActual(); //1.2 (se podría omitir "this.")
                //Que ciudad es de tipo String también nos lo diría el diagrama de clases
            
                //El fragmento alt se suele usar para condicionales con else
            if(ciudad!=null){ // zona de encima de la línea punteada en el fragmento alt
                tiempo = meteo.dimeTiempo(ciudad, dia); //1.3
            } else { //zona debajo de la línea punteada en el fragmento alt
                tiempo = meteo.dimeTiempo(ciudadHabitual,dia); //1.4
            }
        }
        
        return tiempo; //No debemos olvidar el return porque el paso 1 devuelve el valor de tiempo
    
    }
    
    /*
    * Corresponde a la implementación de la transparencia 11 de la unidad 07
    */    
    String dimeTiempo(ArrayList<Date> fechas){
        
        //Declaramos las variables locales fuera del bucle
        Date dia;
        String tiempoDia;
        String tiempo = "";
        
        for(int i=0; i<fechas.size(); i++) //El bucle itera sobre todos los elementos de la lista fechas
        {
            dia = fechas.get(i); //1.1
                //Cuando el receptor del mensaje es un multiobjeto (una colección)
                //se usa el método que corresponda para ese tipo de colección.
                //Por ejemplo, aquí estamos trabajando con ArrayList, luego "siguiente"
                //indica acceder al siguiente elemento, lo cual hacemos con get(i)
                
            tiempoDia = this.dimeTiempo(dia); //1.2
            tiempo += tiempoDia; //Nota
        }
        
        /*
        Una alternativa mejor es:
        
        for(Date dia: fechas)
        {
            tiempoDia = this.dimeTiempo(dia);
            tiempo += tiempoDia;
        }
        */
        
        return tiempo; // No debemos olvidar el return
    }

    private String posicionActual() {
        throw new UnsupportedOperationException("Método todavía sin implementar"); 
    }

    private Date diaActual() {
        throw new UnsupportedOperationException("Método todavía sin implementar"); 
    }
            
}
