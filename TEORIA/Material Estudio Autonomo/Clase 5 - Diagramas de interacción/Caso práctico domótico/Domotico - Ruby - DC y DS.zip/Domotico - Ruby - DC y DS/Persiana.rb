module domotica

  class Persiana

    @@incrementoAltura = 0.2

    def initialize(altura)
      @altura = altura
    end

    def subir
    end

    def bajar
    end

    def estaArriba
    end

  end
end
