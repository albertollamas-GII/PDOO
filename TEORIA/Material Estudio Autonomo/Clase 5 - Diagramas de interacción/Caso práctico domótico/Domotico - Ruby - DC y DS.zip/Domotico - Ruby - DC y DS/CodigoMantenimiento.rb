module mantenimiento
  module CodigoMantenimiento
    CAMBIARBOMBILLA = :cambiarbombilla
    CAMBIARPERSIANA = :cambiarpersiana
    OK =:ok
  end
end
