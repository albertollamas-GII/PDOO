package domotica;

public class Main {

    public static void main(String[] args) {
        Lavabo lavabo = new Lavabo(0);
        Dormitorio dormitorio = new Dormitorio(1, 2);
        
        lavabo.subirLuz();
        dormitorio.subirLuz();
        dormitorio.subirLuz();
        dormitorio.bajarLuz();
        
        // crear un labavo y asignar a habitacion2
        //Habitacion habitacion2 = ;

        // crear un dormitorio con una cama y asignar a habitacion3
        //Habitacion habitacion3 = ;

        // subir la luz a habitacion2 y habitacion3 y comprobar con el depurador

        
        // obtener número de camas de la habitación3, ya que contiene un dormitorio, ¿se puede hacer directamente?

        
        // obtener número de camas de la habitación3 mediante casting

        
        // comprobar el tipo de habitacion2 y si es un dormitorio mostrar "Es un dormitorio" y si no "Es un lavabo"
		// ATENCIÓN: ESTO QUE VAS A HACER ESTÁ MAL (SE PENALIZA EN LOS EXÁMENES), LA SOLUCIÓN CORRECTA LA HARÁS MÁS ABAJO

        
		// ESTA ES LA SOLUCIÓN CORRECTA
        // hacer las modificaciones necesarias en las clases para que se muestre lo que es la habitacion2 sin necesitar la comprobación del tipo

        
    }    
}
