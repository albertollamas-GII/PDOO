package domotica;

public class Habitacion {
    private int idHabitacion;
    protected boolean bombillaEncendida; // true = encendida, false = apagada
    
    public Habitacion(int idHabitacion) {
        this.idHabitacion = idHabitacion;
        this.bombillaEncendida = false;
    }

    public int getIdHabitacion() {
        return idHabitacion;
    }

    public void subirLuz() {
        this.bombillaEncendida = true;
    }

    public void bajarLuz() {
        this.bombillaEncendida = false;
    }
}
