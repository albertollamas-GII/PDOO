package Copia_c_constructor_copia;

public class Main {
    public static void main(String[] args) {
        A a1 = new A(11, 22);
        A a2 = new B(111 , 222 , 333);
        A a3;

        // El que se ejecute esta línea o la siguiente determina
        // el constructor copia al que llamar

        //a3 = a1;
        a3 = a2;
        
        A a4 = null;

        // ¿a3 es un A o un B?

        //a4 = new A(a3);
        a4 = new B((B)a3);

        System.out.print(a4);
    }    
}
