package Copia_c_constructor_copia;

class A {
    private int x;
    private int y;

    public A(int a, int b) {
        x = a;
        y = b;
    }

    public A(A a) {
        x = a.x;
        y = a.y;
    }

    @Override
    public String toString() {
        return "(" + Integer.toString(x) + ", " + Integer.toString(y) + ") ";
    }
}
