package Copia_c_constructor_copia;

import java.lang.reflect.*;
import jdk.incubator.jpackage.internal.Log;
import jdk.internal.joptsimple.internal.Reflection;

public class Main_reflexion {
    public static void main(String[] args) {
        A a1 = new A(11, 22);
        A a2 = new B(111 , 222 , 333);
        A a3;

        // El que se ejecute esta línea o la siguiente determina
        // el constructor copia al que llamar

        a3 = a1;
        //a3 = a2;
        
        A a4 = null;

        // ¿a3 es un A o un B?


        // Obtenemos el constructor copia
        Class cls = a3.getClass();
        Constructor constructor = null;
        try {
            constructor = cls.getDeclaredConstructor(cls);
        } catch ( NoSuchMethodException e ) { }

        // Usamos el constructor copia
        try {
            a4 =(A)((constructor == null)?null:constructor.newInstance(a3));
        } catch ( InstantiationException ex ) {
            //Logger.getLogger(Reflection.class.getName()).log(System.Logger.Level.SEVERE,null,ex);
        } catch ( IllegalAccessException ex ) {
            //Logger.getLogger(Reflexion.class.getName()).log (Level.SEVERE,null,ex);
        } catch ( IllegalArgumentException ex ) {
            //Logger.getLogger(Reflexion.class.getName()).log(Level.SEVERE,null,ex);
        } catch ( InvocationTargetException ex ) {
            //Logger.getLogger( Reflexion.class.getName()).log(Level.SEVERE, null , ex);
        }

        System.out.print(a4);

    }
}
