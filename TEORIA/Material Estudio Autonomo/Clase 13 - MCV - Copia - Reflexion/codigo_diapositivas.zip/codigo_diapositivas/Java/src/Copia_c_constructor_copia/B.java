package Copia_c_constructor_copia;

class B extends A {
    private int z;

    public B(int a, int b, int c) {
        super(a,b);
        z = c;
    }

    public B(B b) {
        super(b);
        z = b.z;
    }

    @Override
    public String toString() {
        return super.toString() + "(" + Integer.toString(z) + ") " ;
    }
}
