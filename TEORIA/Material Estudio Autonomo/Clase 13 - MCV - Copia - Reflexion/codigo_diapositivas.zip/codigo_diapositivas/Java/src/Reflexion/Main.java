package Reflexion;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

class Persona {
    private String nombre ;

    public Persona(String n) {
        nombre=n ;
    }

    public void setNombre(String n) {
        nombre=n ;
    }
}

public class Main {
    public static void main(String[] args) {
        // Ejemplos
        Persona per = new Persona("Pepa");

        Class clase = per.getClass(); // método definido en Object

        Field[] varInstancia = clase.getDeclaredFields(); // métodos definidos en Class

        Constructor[] construct = clase.getConstructors();

        Method[] metodosInstancia = clase.getMethods();

        String nombreClase = clase.getSimpleName();
    }    
}
