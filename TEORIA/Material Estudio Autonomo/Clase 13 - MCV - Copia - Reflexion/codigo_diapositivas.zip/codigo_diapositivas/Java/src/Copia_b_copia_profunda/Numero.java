package Copia_b_copia_profunda;

class Numero implements Cloneable {
    private Integer i ;

    public Numero (Integer a) {
        i = a ; }

    public void inc() {
    i ++; }

     @Override
    public Numero clone() throws CloneNotSupportedException {

        return (Numero)super.clone();

        // Los objetos de la clase Integer son inmutables
        // por ello, la implementación realizada es válida
        // no siendo necesaria la implementación que está comentada
        // Ésta sí serí a necesaria para objetos mutables
        
        /*
        Numero nuevo = (Numero) super . clone ( )
        nuevo . i = i . clone ( ) ;
        r e t u r n nuevo ;
        */
    }
    @Override
    public String toString ( ) {
        return i.toString( ) ;
    }    

}