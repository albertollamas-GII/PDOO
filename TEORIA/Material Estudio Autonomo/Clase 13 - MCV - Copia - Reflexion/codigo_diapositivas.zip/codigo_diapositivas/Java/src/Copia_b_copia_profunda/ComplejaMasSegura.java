package Copia_b_copia_profunda;

import java.util.ArrayList;

class ComplejaMasSegura implements Cloneable {
    private ArrayList<Numero> numeros;

    public ComplejaMasSegura ( ) {
        numeros = new ArrayList();
    }

    public void add(Numero i) {
        numeros.add(i);
    }

    ArrayList<Numero> getNumeros ( ) {
        // Este método hace una copia profunda de cada uno de los elementos de la colección
        // numeros en un nuevo array
        ArrayList nuevo = new ArrayList<>();
        Numero n = null;
        for (Numero i : this.numeros ) {
            try {
                n = i.clone();
            } catch (CloneNotSupportedException e) {
                System.err.println("CloneNotSupportedException");
            }
            nuevo.add(n);
        }
        return (nuevo);
    }

    @Override
    public ComplejaMasSegura clone() throws CloneNotSupportedException {
        ComplejaMasSegura nuevo= (ComplejaMasSegura) super.clone();
        nuevo.numeros = this.getNumeros(); // Ya se hace copia profunda
        return nuevo ; 
    }

    // También habría que modificar el método public void add (Numero i )
    // ¿Cómo se implementaría?
}
