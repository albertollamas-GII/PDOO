package Copia_b_copia_profunda;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Sin copia profunda
        //ComplejaSegura c1 = new ComplejaSegura();
        // Con copia profunda
        ComplejaMasSegura c1 = new ComplejaMasSegura();

        c1.add(new Numero(3));
        c1.add(new Numero(2));

        c1.getNumeros().clear();
        for (Numero i : c1.getNumeros()) {
            System.out.println(i);
        } // R −−> 3 2 OK! :−)

        ArrayList<Numero> an = c1.getNumeros();
        Numero n = an.get(0);
        n.inc(); // Sigue siendo un problema

        for (Numero i : c1.getNumeros()) {
            System.out.println(i);
        } // R−−> 4 2 : −(
    }    
}
