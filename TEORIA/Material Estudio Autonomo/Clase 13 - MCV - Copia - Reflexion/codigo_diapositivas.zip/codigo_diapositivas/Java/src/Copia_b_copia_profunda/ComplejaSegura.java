package Copia_b_copia_profunda;

import java.util.ArrayList;

public class ComplejaSegura {
    private ArrayList<Numero> numeros;

    public ComplejaSegura ( ) {
        numeros = new ArrayList();
    }

    public void add(Numero i) {
        numeros.add(i);
    }

    ArrayList<Numero> getNumeros() {
        return (ArrayList<Numero>) (numeros.clone());
        // Usamos clone para devolver una copia del estado de numeros
    }
}
