package Copia_a_copia;

import java.util.ArrayList;

public class Compleja {
    // Clase mutable que referencia a objetos mutables
    private ArrayList<Numero> numeros ;

    public Compleja() {
        numeros = new ArrayList<>() ;
    }

    public void add(Numero i) {
        numeros.add(i);
    }
    
    ArrayList<Numero> getNumeros() {
        return numeros;
    }
}
