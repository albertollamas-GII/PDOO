package Copia_a_copia;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Compleja c1 = new Compleja();

        c1.add(new Numero(1));
        c1.add(new Numero(2)) ;

        // Acceso sin restricción a la lista
        ArrayList<Numero> an = c1.getNumeros();
        an.clear();
        c1.add(new Numero(33));

        for(Numero i : c1.getNumeros()) {
            System.out.println(i); // R−−> 33
        }
        // Se devuelven referencias al estado interno
        Numero n = c1.getNumeros().get(0);
        n.inc();

        for (Numero i : c1.getNumeros()) {
            System.out.println(i); // R−−> 34
        }
    }
}
