package Copia_a_copia;

public class Numero {
    private Integer i ;

    public Numero ( Integer a ) {
        i = a ;
    }

    public void inc ( ) {
        // Este método modifica el estado del objeto
        // La clase es mutable
        i ++;
    }

    @Override
    public String toString ( ) {
        return i.toString( ) ;
    }    
}
