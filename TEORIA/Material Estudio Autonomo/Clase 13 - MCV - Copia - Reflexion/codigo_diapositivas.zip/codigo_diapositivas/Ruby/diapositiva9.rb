class Libro
  def initialize(titulo)
    @titulo = titulo
  end
end

libro1 = Libro.new( " El señor de los anillos")

# Se modifica solo una instancia
libro1.instance_eval do def autor (autor)
                          @autor = autor
                        end
end

libro1.autor("J.R.R. Tolkien")
puts libro1.inspect

libro2 = Libro.new( " Cien años de soledad " )
libro2.autor("G. García Márquez") # undefined method ‘ autor ’