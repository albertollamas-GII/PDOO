class Libro
  def initialize(titulo)
    @titulo = titulo
  end
end

libro1 = Libro.new( " El señor de los anillos")

# Se modifica la clase y afecta a todas las instancias
Libro.class_eval do def publicacion(aniopublicacion)
                      @anioPublicacion = aniopublicacion
                    end
end

libro1.publicacion(1997) # Se invoca el nuevo método

# Se modifica solo una instancia
libro1.instance_eval do def autor (autor)
                        @autor = autor
                    end
end

libro1.autor("J.R.R. Tolkien")

libro2 = Libro.new( " Cien años de soledad " )

puts Libro.instance_methods(false) # publicacion
# El parámetro indica si queremos solo los métodos de esa clase (false)
# o también los heredados (true)

puts libro1.instance_variables
  # @titulo
  # @anioPublicacion
  # @autor

puts libro2.instance_variables # @titulo
puts libro1.instance_of?(Libro) # true
