class Libro
  def initialize(titulo)
    @titulo = titulo
  end
end

libro1 = Libro.new( " El señor de los anillos")

# Se modifica la clase y afecta a todas las instancias
Libro.class_eval do def publicacion(aniopublicacion)
                      @anioPublicacion = aniopublicacion
                    end
end

libro1.publicacion(1997) # Se invoca el nuevo método
puts libro1.inspect # Ahora tiene un atributo adicional
