class Vampiro
  @@guarida = "CastilloSiniestro"
  
  def self.mostrarGuarida
    puts @@guarida
  end
  
end

class VampiroCool < Vampiro

end

class VampiroHermano < Vampiro
  
end

class VampiroNieto < VampiroCool
  @@guarida = "CasaDisenio"  
end

Vampiro.mostrarGuarida
VampiroCool.mostrarGuarida
VampiroNieto.mostrarGuarida
VampiroHermano.mostrarGuarida
