/*
 * Corresponde al ejemplo de la transparencia 10 de la unidad 11 - Clases Parametrizables
 */

package estudiantescursos;

public abstract class Estudiante {

    private String nombre;
    
    Estudiante(String nombre){
        this.nombre = nombre;
    }
    
    String getNombre(){
        return nombre;
    }
    
    abstract String presentarse();
        
}
