/*
 * Corresponde al ejemplo de la transparencia 10 de la unidad 11 - Clases Parametrizables
 */
package estudiantescursos;

public class Prueba {

    public static void main(String[] args) {
        EstudiantePrimaria p1 = new EstudiantePrimaria("Pablo");
        EstudianteSecundaria p2 = new EstudianteSecundaria("Marta");
        EstudianteSecundaria p3 = new EstudianteSecundaria("Manuel");
        
        Curso<EstudianteSecundaria> primeroeso = new Curso<>();
        primeroeso.matricularEstudiante(p1); //No deja matricular a p1 porque no es un estudiante de secundaria
        primeroeso.matricularEstudiante(p2);
        primeroeso.matricularEstudiante(p3);
        
    }
    
}
