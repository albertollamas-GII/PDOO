/*
 * Corresponde al ejemplo de la transparencia 10 de la unidad 11 - Clases Parametrizables
 */
package estudiantescursos;

public class EstudianteSecundaria extends Estudiante{
    
    EstudianteSecundaria(String nombre){
        super(nombre);
    }    

    @Override
    String presentarse() {
        return getNombre()+", estudiante de secundaria";
    }
    
    
}