/*
 * Corresponde al ejemplo de la transparencia 10 de la unidad 11 - Clases Parametrizables
 */
package estudiantescursos;

public class Curso <T extends Estudiante>{
    void matricularEstudiante(T estudiante){
        System.out.println("Matriculo a: "+estudiante.presentarse());
    }
}
