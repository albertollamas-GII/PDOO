/*
 * Corresponde al ejemplo de la transparencia 10 de la unidad 11 - Clases Parametrizables
 */
package estudiantescursos;

public class EstudiantePrimaria extends Estudiante{
    
    EstudiantePrimaria(String nombre){
        super(nombre);
    }    

    @Override
    String presentarse() {
        return getNombre()+", estudiante de primaria";
    }
    
    
}
