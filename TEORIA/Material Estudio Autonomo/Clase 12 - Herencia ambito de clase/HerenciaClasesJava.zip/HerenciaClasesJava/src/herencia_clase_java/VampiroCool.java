
package herencia_clase_java;


public class VampiroCool extends Vampiro {
   
    // Shadowing 
    public static String guarida = "CasaDiseño";
     
    // Get Propio
    public static String getGuarida(){return guarida;}
    
    // Set Propio
    public static void setGuarida(String g){guarida = g;}
    
}
