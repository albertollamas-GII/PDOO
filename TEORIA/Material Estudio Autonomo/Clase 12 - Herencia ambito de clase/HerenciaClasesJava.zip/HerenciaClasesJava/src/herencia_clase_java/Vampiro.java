package herencia_clase_java;


public class Vampiro {
    public static String guarida = "CastilloSiniestro";
    
    public String atrinstancia;
    
    public static void setGuarida(String g){guarida = g;}
    public static String getGuarida(){return guarida;}
}
