
package herencia_clase_java;

public class Main {

//Prueba cómo funciona la herencia con atributos y metódos de clase en Java:
    
    public static void main(String[] args) {
        
        System.out.println(Vampiro.getGuarida());
        System.out.println(VampiroCool.getGuarida());
        VampiroCool.setGuarida("Cueva");
        System.out.println(VampiroCool.getGuarida());
        System.out.println(Vampiro.getGuarida());
   }
    
}
