package domotica;

public class Main {

    public static void main(String[] args) {
        Lavabo lavabo = new Lavabo(0);
        Dormitorio dormitorio = new Dormitorio(1, 2);
        
        lavabo.subirLuz();
        dormitorio.subirLuz();
        dormitorio.subirLuz();
        dormitorio.bajarLuz();
        
        // crear un labavo y asignar a habitacion2
        Habitacion habitacion2 = new Lavabo(2);
        // crear un dormitorio con una cama y asignar a habitacion3
        Habitacion habitacion3 = new Dormitorio(3, 1);
        // subir la luz a habitacion2 y habitacion3 y comprobar con el depurador
        habitacion2.subirLuz();        
        habitacion3.subirLuz();
        
        // obtener número de camas de la habitación3, ya que contiene un dormitorio, ¿se puede hacer directamente?
        //habitacion3.getCamas();
        
        // obtener número de camas de la habitación3 mediante casting
        ((Dormitorio) habitacion3).getCamas();
        
        // comprobar el tipo de habitacion2 y si es un dormitorio mostrar "Es un dormitorio" y si no "Es un lavabo"
        if (habitacion2 instanceof Dormitorio)
            System.out.println("Es un dormitorio");
        else
            System.out.println("Es un lavabo");

        // hacer las modificaciones necesarias en las clases para que se muestre lo que es la habitacion2 sin necesitar la comprobación del tipo
        habitacion2.mostrar();
    }    
}
