package domotica;

public class Lavabo extends Habitacion {
    public Lavabo(int idHabitacion) {
        super(idHabitacion); // inicialización de los atributos heredados
    }

    @Override
    public void mostrar() {
        System.out.println("Es un lavabo");
    }
}
