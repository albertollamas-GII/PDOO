package base;

import base2.C;

public class D extends C {
    protected int protegidoD = 3;
}