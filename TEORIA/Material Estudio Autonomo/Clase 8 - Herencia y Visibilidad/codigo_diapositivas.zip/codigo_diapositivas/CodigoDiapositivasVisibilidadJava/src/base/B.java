package base;

public class B extends A {
    protected int protegidoB = 1;
}
