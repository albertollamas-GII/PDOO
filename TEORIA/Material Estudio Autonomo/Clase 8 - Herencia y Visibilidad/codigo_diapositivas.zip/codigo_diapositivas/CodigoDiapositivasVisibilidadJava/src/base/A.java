package base;

public class A {
    protected int protegidoA = 0;    
}
