require_relative 'habitacion'

module Domotica
  class Dormitorio < Habitacion
    def initialize(idHabitacion)
      super # inicialización de los atributos heredados
      @persianaSubida = false # inicialización del atributo propio
    end

    def subirLuz
      if (!@persianaSubida)
        @persianaSubida = true
      else
        super # para encender la bombilla se llama al método subirLuz del padre
      end
    end

    def bajarLuz
      if (@bombillaEncendida) # se puede acceder desde el hijo al atributo privado del padre
        super # para bajar la luz se llama al método bajarLuz del padre
      else
        @persianaSubida = false
      end
    end

  end
end
