require_relative 'habitacion'

module Domotica
  class Lavabo < Habitacion
    def initialize(idHabitacion)
      super # inicialización de los atributos heredados
    end

  end
end