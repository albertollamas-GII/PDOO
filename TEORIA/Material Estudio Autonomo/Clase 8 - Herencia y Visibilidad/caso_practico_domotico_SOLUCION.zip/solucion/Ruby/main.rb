require_relative 'lavabo'
require_relative 'dormitorio'

lavabo = Domotica::Lavabo.new(0)
dormitorio = Domotica::Dormitorio.new(1)

lavabo.subirLuz
dormitorio.subirLuz
dormitorio.subirLuz
dormitorio.bajarLuz
