package domotica;

public class Main {

    public static void main(String[] args) {
        Lavabo lavabo = new Lavabo(0);
        Dormitorio dormitorio = new Dormitorio(1);
        
        lavabo.subirLuz();
        dormitorio.subirLuz();
        dormitorio.subirLuz();        
    }
    
}
