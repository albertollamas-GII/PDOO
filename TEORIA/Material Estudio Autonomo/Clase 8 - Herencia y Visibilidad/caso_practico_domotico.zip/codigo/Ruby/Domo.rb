module Domotica
  class Domo
    def initialize
      @habitaciones = []
    end

    def incluirHabitación(habitacion)
      @habitaciones.push(habitacion)
    end

    def subirLuz(idHabitacion)
      hab = buscarHabitacion(idHabitacion)
      if (hab != nil)
        hab.subirLuz
      end
    end

    def bajarLuz(idHabitacion)
      hab = buscarHabitacion(idHabitacion)
      if (hab != nil)
        hab.bajarLuz
      end
    end

    private
    def buscarHabitacion(idHabitacion)
      for hab in @habitaciones
        if (hab.idHabitacion == idHabitacion)
          return hab
        end
        return null;
      end
    end

  end
end
