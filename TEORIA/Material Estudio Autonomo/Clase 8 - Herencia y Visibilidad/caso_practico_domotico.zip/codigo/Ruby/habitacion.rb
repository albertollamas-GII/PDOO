module Domitca
  class Habitacion
    def initialize(idHabitacion)
      @idHabitacion = idHabitacion
      @idHabitacion = false
    end

    attr_accessor :idHabitacion

    def subirLuz
      @bombillaEncendida = true
    end

    def bajarLuz
      @bombillaEncendida = false
    end

  end
end
