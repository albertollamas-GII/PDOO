/*
 * Código correspondiente a los ejemplos de la transparencia 13 de la unidad 06
 */
package pkg06_tr13;

public class Cita {
    //Atributos básicos (No existen ahora mismo en este paquete las clases Time
    //y médico, por eso da error)
    private Time hora;
    private Medico facultativo;
}
