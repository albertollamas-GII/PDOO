/*
 * Código correspondiente a los ejemplos de la transparencia 13 de la unidad 06
 */
package pkg06_tr13;

import java.util.ArrayList;

class Articulo {
    
    //Atributos básicos
    private String nombre;
    private final float precioPartida;
    
    //Atributos de referencia
    ArrayList<Postor> postores  = new ArrayList();
    Postor mejorPostor;
    
    //Métodos
    
    public Articulo(float precioPartida, String nombre){
        this.nombre = nombre;
        this.precioPartida = precioPartida;
    }
    
    public void añadirPuja(float puja, Postor postor){
    
    }
    
    public void asignarAlMejorPostor(){
    
    }   
}
