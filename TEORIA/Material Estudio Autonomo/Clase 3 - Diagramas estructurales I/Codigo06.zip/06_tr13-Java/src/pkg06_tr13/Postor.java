/*
 * Código correspondiente a los ejemplos de la transparencia 13 de la unidad 06
 */
package pkg06_tr13;

import java.util.ArrayList;

/**
 * @author Zoraida Callejas, Grupo B PDOO
 */
class Postor {
    
    //Atributos básicos
    private float dineroDisponible;
    
    //Atributos de referencia
    private ArrayList<Articulo> pujas = new ArrayList();
    private ArrayList<Articulo> compras = new ArrayList();
    
    //Métodos
    public Postor(float dinero){
    
    }
    
    public Boolean pujar(Articulo a, float puja){
        return false; // para que no de error
    }
    
    public void asignarArticulo(Articulo a){
    
    }
            
}
