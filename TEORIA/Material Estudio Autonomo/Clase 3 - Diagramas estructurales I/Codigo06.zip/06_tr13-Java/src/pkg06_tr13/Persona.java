/*
 * Código correspondiente a los ejemplos de la transparencia 13 de la unidad 06
 */
package pkg06_tr13;

import java.util.ArrayList;

public class Persona {
    //Atributos de referencia - He puesto los nombres en plural para que 
    //quede claro que puede haber varios
    ArrayList<Persona> tutorizados = new ArrayList(); 
    ArrayList<Persona> tutores = new ArrayList(2); 
    
    /**
     * Ojo: "tutorLegal>" lleva una flecha en el diagrama, luego no es un rol 
     * en la asociación, no indica el nombre de un atributo de referencia, 
     * sino que nos dice cuál es la "semántica" de esa relación, 
     * que esa asociacion se puede leer como "Persona es tutor legal de Persona". 
     * Ayuda a interpretar el diagrama pero no tiene incidencia en la implementación.
     **/
}
