/*
 * Código correspondiente a los ejemplos de la transparencia 13 de la unidad 06
 */
package pkg06_tr13;

import java.util.ArrayList;

class Paciente {
    //Atributos básicos
    private int id;
    
    //Atributos de referencia
    ArrayList<Cita> citas = new ArrayList();
}
