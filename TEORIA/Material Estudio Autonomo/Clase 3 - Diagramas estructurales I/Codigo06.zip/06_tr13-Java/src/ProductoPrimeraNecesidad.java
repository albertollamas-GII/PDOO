/*
 * Código correspondiente a los ejemplos de la transparencia 11 de la unidad 06
 */

public class ProductoPrimeraNecesidad {
    PuntoDistribucion distribuidor;
}
