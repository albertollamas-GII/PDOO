
import java.util.ArrayList;

/*
 * Código correspondiente a los ejemplos de la transparencia 12 de la unidad 06
 */
public class PuntoDistribucion {
    ArrayList<ProductoPrimeraNecesidad> bienes;
}
