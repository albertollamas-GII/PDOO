
# Código correspondiente al ejemplo de la transparencia 10 de la unidad 06

#
# Al implementar la clase no debemos olvidar que en Ruby
# - No se indican los tipos
# - Los atributos son siempre privados
# - Para los métodos, sólo consideraremos visibilidad pública (por defecto), privada
# o protegida. La visibilidad de paquete es propia de Java.
#
class ProductoPrimeraNecesidad

  attr_writer :tasaIVA #setTasaIVA

  @@tasaIVA = 4.0

  def initialize
    @componentes = Array.new
    @nombre = ""
    @perecedero = false
    @precioSinIVA = 0.0
  end

  def precio
  end

end
