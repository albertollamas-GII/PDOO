# Código correspondiente al ejemplo de la transparencia 21 de la unidad 06
#

class Cliente
  def initialize(nombre,domicilio,cif,gestor)
    @nombre = nombre
    @domicilio = domicilio
    @CIF = cif
    @gestor = gestor # Atributo de referencia
  end
end
