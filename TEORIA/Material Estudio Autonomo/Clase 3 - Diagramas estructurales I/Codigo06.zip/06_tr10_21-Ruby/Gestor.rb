
# Código correspondiente al ejemplo de la transparencia 21 de la unidad 06


require_relative 'Factura' #Factura se usará en algún momento dentro de la clase Gestor,
                            # (p.ej. dentro de algún método) pero no es un atributo de referencia

class Gestor

  def initialize
    @clientes = Array.new #Atributo de referencia lista de clientes
  end

  def generarFactura

  end

  def gestionar(cli)

  end

end
