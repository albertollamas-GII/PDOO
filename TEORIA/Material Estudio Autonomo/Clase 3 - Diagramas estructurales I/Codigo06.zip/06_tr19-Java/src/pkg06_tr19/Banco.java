/*
 * Código correspondiente a los ejemplos de la transparencia 19 de la unidad 06
 */
package pkg06_tr19;

import java.util.ArrayList;

public class Banco {
    private String nombre;
    private String domicilio;
    private String swift;
    private ArrayList<CuentaBancaria> cuentas = new ArrayList();
}
