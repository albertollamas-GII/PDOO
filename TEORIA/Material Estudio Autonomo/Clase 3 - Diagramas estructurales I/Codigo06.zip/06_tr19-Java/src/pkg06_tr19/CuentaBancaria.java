/*
 * Código correspondiente a los ejemplos de la transparencia 19 de la unidad 06
 */
package pkg06_tr19;

public class CuentaBancaria {
    private String iban;
    private String nifTitular;
    private float saldo;
}
