/*
 * Código correspondiente a los ejemplos de la transparencia 14 de la unidad 06
 */
package pkg06_tr14;

import java.util.ArrayList;

public class Empresa {
    private String cif;
    private ArrayList<Contrato> empleados = new ArrayList();
}
