/*
 * Código correspondiente a los ejemplos de la transparencia 14 de la unidad 06
 */
package pkg06_tr14;

import java.util.ArrayList;

/**
 * @author Zoraida Callejas, Grupo B PDOO
 */
public class Trabajador {
    private String nif;
    private ArrayList<Contrato> contratos;
    
}
