/*
 * Código correspondiente a los ejemplos de la transparencia 10 de la unidad 06
 */
package pkg06_tr10;

import java.util.ArrayList;


public class ProductoPrimeraNecesidad {
   
    public static float tasaIVA = 4.0f;
    private ArrayList<String> componentes = new ArrayList(); //Podría usar cualquier otro tipo de colección de Strings
    protected String nombre;
    Boolean perecedero; //Por defecto visbilidad de paquete
    private float precioSinIVA;
    
    public float precio(){
        //Los diagramas de clase sólo indican estructura, no cómo se implementan
        //los métodos, eso lo estudiaremos más adelante con los diagramas de interacción
        return 0.0f; //Para que no de error por ahora
    }       
    
    public void setTasaIVA(float nuevaTasa){
        
    }
}
