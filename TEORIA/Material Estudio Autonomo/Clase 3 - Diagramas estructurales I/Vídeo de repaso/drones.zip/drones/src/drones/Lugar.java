
package drones;


public class Lugar {
    private int latitud;
    private int longitud;
    
    public float distancia(Lugar punto){
        return 0.0f; //Para que no de error
    }
}

