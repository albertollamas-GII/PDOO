
package drones;

import java.util.ArrayList;

class Controlador {
    ArrayList<Dron> aparatos;
    
    public void llevarDronA(Lugar punto){
    }
    
    public float alturaDron(int idDron){
        return 0.0f; //Para que no muestre error
    }
    
    public void incluirNuevoDron(Dron dron, Lugar lugar){
    }
    
    public void aterrizarDronesBajoAltura(float alt){
    }
    
    private Dron dronMasCercano(Lugar punto){
        return null; //Para que no muestre error
    }
    
    private Dron getDron(int idDron){
        return null; //Para que no muestre error
    }
}
