/**
 * Implementación del diagrama DC - Villanos
 */

package esbirros;

public class Mayordomo {
    
}
