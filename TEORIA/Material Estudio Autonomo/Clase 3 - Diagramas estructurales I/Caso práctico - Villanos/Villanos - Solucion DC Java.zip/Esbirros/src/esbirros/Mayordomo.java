/**
 * Implementación del diagrama DC - Esbirros 
 * (Ver material complementario de la unidad 6)
 */

package esbirros;

public class Mayordomo {
    
}
