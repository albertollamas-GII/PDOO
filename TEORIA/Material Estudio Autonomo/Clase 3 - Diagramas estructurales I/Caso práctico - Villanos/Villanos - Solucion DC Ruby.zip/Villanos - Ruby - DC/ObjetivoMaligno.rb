# Implementación del diagrama DC - Villanos

module Villanos
  class ObjetivoMaligno

      attr_accessor :descripcion

      def initialize(descripcion)
        @descripcion = descripcion
      end
  end

end
