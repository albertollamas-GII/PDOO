
package maquinaria;

/*
 * Solución al diagrama "DC - Trenes.jpg"
 */
class Maquina {

    //Atributos básicos:
    String tipo; //Visibilidad paquete
    private float potencia;
    
    //No tiene atributos de referencia porque no se puede navegar de Maquina a Convoy
    
    //Cabecera de los métodos:
    public void reparar(){
    }
   
}
