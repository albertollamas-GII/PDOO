
package maquinaria;

/*
 * Solución al diagrama "DC - Trenes.jpg"
 */
public class Asiento {
    
    //Atributos básicos:
    private int fila;
    private char letra;
    private Boolean libre;
    
    //Atributos de referencia:
    private Vagon vagon;
}
