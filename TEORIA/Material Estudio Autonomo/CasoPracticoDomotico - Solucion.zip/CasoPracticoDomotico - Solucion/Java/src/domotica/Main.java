package domotica;

public class Main {

    public static void main(String[] args) {
        
        Dormitorio h1 = new Dormitorio(1, 2);
        Dormitorio h2 = new Dormitorio (2, 1);
        Lavabo l1 = new Lavabo(3);
        Lavabo l2 = new Lavabo(4);
        
        LimpiezaEspecializada<Dormitorio> limpiaDormitorios = new LimpiezaEspecializada<>();
        limpiaDormitorios.limpiar(h1);
        limpiaDormitorios.limpiar(h2);
        //limpiaDormitorios.limpiar(l1);
        
        LimpiezaEspecializada<Lavabo> limpiaLavabos = new LimpiezaEspecializada<>();
        limpiaLavabos.limpiar(l1);
        //limpiaLavabos.limpiar(h2);
        
        
        LimpiezaEspecializada<Habitacion> limpiaTodo = new LimpiezaEspecializada<>();
        limpiaTodo.limpiar(h1);
        limpiaTodo.limpiar(l1);
        
        
    }    
}
