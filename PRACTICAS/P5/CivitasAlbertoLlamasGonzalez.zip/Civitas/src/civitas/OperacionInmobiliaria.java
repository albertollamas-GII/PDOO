/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author albertollamasgonzalez
 */
public enum OperacionInmobiliaria {
    CONSTRUIR_CASA,
    CONSTRUIR_HOTEL,
    TERMINAR 
}

//SE PUEDE ACCEDER A CADA UNO DE LOS VALORES CON OperacionInmobiliaria.values()[2]