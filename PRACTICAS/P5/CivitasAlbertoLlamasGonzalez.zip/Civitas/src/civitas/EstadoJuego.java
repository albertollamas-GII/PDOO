
package civitas;

enum EstadoJuego {
  INICIO_TURNO,
  DESPUES_AVANZAR,
  DESPUES_COMPRAR,
  DESPUES_GESTIONAR
}
