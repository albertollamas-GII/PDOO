
package civitas;

enum EstadosJuego {
  INICIO_TURNO,
  DESPUES_AVANZAR,
  DESPUES_COMPRAR,
  DESPUES_GESTIONAR
}
